// NeverMiss background service worker
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "save_moment") {
    chrome.storage.local.get({ moments: [] }, ({ moments }) => {
      moments.push(msg.payload);
      chrome.storage.local.set({ moments }, () => {
        chrome.notifications?.create?.({
          type: "basic",
          iconUrl: "icon.png",
          title: "NeverMiss",
          message: `Saved ${msg.payload.name}'s ${msg.payload.occasion}. We'll remind you next year.`,
        });
        // schedule a yearly alarm (~365 days)
        chrome.alarms?.create?.(`moment:${msg.payload.name}:${msg.payload.occasion}`, {
          delayInMinutes: 60 * 24 * 364,
        });
        sendResponse?.({ ok: true });
      });
    });
    return true;
  }
});

chrome.alarms?.onAlarm.addListener((alarm) => {
  const [, name, occasion] = alarm.name.split(":");
  chrome.notifications?.create?.({
    type: "basic",
    iconUrl: "icon.png",
    title: `Tomorrow: ${name}'s ${occasion}`,
    message: "Open NeverMiss to draft a wish.",
  });
});

// Open side panel on action click (Chrome 114+)
chrome.action?.onClicked?.addListener?.((tab) => {
  if (chrome.sidePanel && tab.windowId) {
    chrome.sidePanel.open({ windowId: tab.windowId }).catch(() => {});
  }
});
